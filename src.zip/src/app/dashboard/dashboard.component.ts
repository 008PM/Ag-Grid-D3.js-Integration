import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular, } from 'ag-grid-angular';
import { HttpClient } from '@angular/common/http';
import { GridOptions, IDatasource, IGetRowsParams, ColDef } from '../../../node_modules/ag-grid-community';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
 // @ViewChild('agGrid', {static: true}) agGrid: AgGridAngular;
  title = 'Ag-grid-basics';
  public gridOptions: GridOptions;
   columnDefs = [
    {headerName: 'Geography', field: 'geography' , sortable: true , filter: true},
    {headerName: 'Category', field: 'category' , sortable: true, filter: true},
    {headerName: 'Brand name', field: 'brand_name' , sortable: true, filter: true},
    {headerName: 'Company name', field: 'company_name' , sortable: true, filter: true },
    {headerName: 'Attributes', field: 'attributes' , sortable: true, filter: true },
    {headerName: 'Years', field: 'years' , sortable: true, filter: true },
    {headerName: 'Attribute Chart', field: 'attribute_chart', sortable: true, filter: true},
];
  rowData: [];
  constructor(private http: HttpClient){}
  ngOnInit() {
   this.GetJSON().subscribe(data => {
      console.log(data);
      this.rowData = data;
    });
  // this.agGrid.columnApi.setColumnsVisible(['attribute_chart'], false);
  }
  Toggleattribute(toggle: string){
   if (toggle === 'category') {
   //this.gridOptions.columnApi.setColumnsVisible(['brand name', 'Company name'], false);
   }
  }
  GetJSON(): Observable <any> {
    return this.http.get('../../assets/MOCK_DATA.json');
  }
}
